package com.spider.app

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText

/** تنسيق موحد: حدود حمراء، داخل أسود، كتابة بيضاء. */
object Ui {
    const val RED = 0xFFE01010.toInt()

    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    fun shape(c: Context, fill: Int = Color.BLACK, stroke: Int = RED, radius: Int = 14, strokeW: Int = 2) =
        GradientDrawable().apply {
            setColor(fill); cornerRadius = dp(c, radius).toFloat(); setStroke(dp(c, strokeW), stroke)
        }

    fun button(c: Context, label: String, onClick: () -> Unit): Button = Button(c).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 16f
        typeface = Typeface.DEFAULT_BOLD
        background = RippleDrawable(ColorStateList.valueOf(0x55E01010), shape(c), null)
        stateListAnimator = null
        minHeight = dp(c, 50)
        setOnClickListener { onClick() }
    }

    fun edit(c: Context, hintText: String): EditText = EditText(c).apply {
        hint = hintText
        setHintTextColor(0xFF777777.toInt())
        setTextColor(Color.WHITE)
        isSingleLine = true
        textDirection = View.TEXT_DIRECTION_LTR
        gravity = Gravity.START or Gravity.CENTER_VERTICAL
        background = shape(c, 0xFF0A0A0A.toInt(), 0xFF8A0000.toInt(), 10, 1)
        setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10))
    }
}
