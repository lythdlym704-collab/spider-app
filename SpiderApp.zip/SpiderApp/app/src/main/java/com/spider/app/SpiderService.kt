package com.spider.app

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PointF
import android.graphics.Rect
import android.graphics.RectF
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams.*
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class SpiderService : AccessibilityService() {
    companion object { var instance: SpiderService? = null }

    private lateinit var wm: WindowManager
    private var spider: SpiderView? = null
    private var lp: WindowManager.LayoutParams? = null
    private var panel: View? = null
    private var extendedAt = 0L
    private val handler = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }
    override fun onUnbind(intent: Intent?): Boolean { hide(); instance = null; return super.onUnbind(intent) }
    override fun onInterrupt() {}

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.packageName == packageName) return
        if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED ||
            e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_SELECTION_CHANGED) {
            // ضغطت على الدالة: يترك العنكبوت الدالة ويبقى ينظر فقط
            if (System.currentTimeMillis() - extendedAt > 1200) retract()
        }
    }

    // ---------- العنكبوت العائم ----------
    fun show() {
        if (spider != null) return
        val size = dp(150)
        val s = SpiderView(this)
        val params = WindowManager.LayoutParams(size, size, TYPE_ACCESSIBILITY_OVERLAY,
            FLAG_NOT_FOCUSABLE or FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(300)
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragged = false
        s.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> { downX = ev.rawX; downY = ev.rawY; startX = params.x; startY = params.y; dragged = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downX; val dy = ev.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) dragged = true
                    if (dragged) { params.x = startX + dx.toInt(); params.y = startY + dy.toInt(); wm.updateViewLayout(s, params) }
                }
                MotionEvent.ACTION_UP -> if (!dragged) togglePanel()
            }
            true
        }
        wm.addView(s, params)
        spider = s; lp = params
    }

    fun hide() {
        closePanel()
        spider?.let { runCatching { wm.removeView(it) } }
        spider = null; lp = null
    }

    // ---------- اللوحة ----------
    private fun closePanel() { panel?.let { runCatching { wm.removeView(it) } }; panel = null }

    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = Ui.shape(this@SpiderService, 0xF2000000.toInt(), Ui.RED, 18, 2)
        }
        val title = TextView(this).apply {
            text = "🕷️ العنكبوت المبرمج"; setTextColor(Color.WHITE); textSize = 17f
            typeface = android.graphics.Typeface.DEFAULT_BOLD; setPadding(0, 0, 0, dp(10))
        }
        val a = Ui.edit(this, "الصق اسم الدالة هنا")
        val b = Ui.edit(this, "الدالة البديلة (للاستبدال)")
        fun fieldLp() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = dp(8) }
        fun btnLp() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            .apply { setMargins(dp(3), dp(6), dp(3), 0) }
        a.layoutParams = fieldLp(); b.layoutParams = fieldLp()

        val go = Ui.button(this, "اذهب") {
            val f = a.text.toString().trim()
            if (f.isEmpty()) toast("الصق اسم الدالة أولاً")
            else {
                closePanel()
                handler.postDelayed({
                    val r = locate(f)
                    if (r == null) toast("لم أجد الدالة على الشاشة") else goTo(r)
                }, 400)
            }
        }
        val rep = Ui.button(this, "استبدال") {
            val o = a.text.toString().trim(); val n = b.text.toString().trim()
            if (o.isEmpty() || n.isEmpty()) toast("أدخل الدالتين")
            else {
                closePanel()
                handler.postDelayed({
                    val c = replaceAll(o, n)
                    toast(if (c > 0) "تم استبدال $c موضع" else "لم يتم العثور على الدالة في حقل قابل للتعديل")
                }, 400)
            }
        }
        val close = Ui.button(this, "إغلاق") { closePanel() }
        go.layoutParams = btnLp(); rep.layoutParams = btnLp(); close.layoutParams = btnLp()

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(go); row.addView(rep); row.addView(close)
        box.addView(title); box.addView(a); box.addView(b); box.addView(row)

        val dm = resources.displayMetrics
        val pl = WindowManager.LayoutParams((dm.widthPixels * 0.92f).toInt(), WRAP_CONTENT,
            TYPE_ACCESSIBILITY_OVERLAY, FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(60)
            softInputMode = SOFT_INPUT_ADJUST_PAN
        }
        wm.addView(box, pl); panel = box
    }

    // ---------- الحركة: يذهب ثم يلمس السطر بإصبعه ----------
    private fun goTo(rect: RectF) {
        val s = spider ?: return; val params = lp ?: return
        val size = params.width; val dm = resources.displayMetrics
        val tx = rect.centerX(); val ty = rect.centerY()
        var cy = ty - size * 0.38f
        if (cy - size / 2 < 0) cy = ty + size * 0.38f
        val nx = (tx - size / 2).coerceIn(0f, (dm.widthPixels - size).toFloat())
        val ny = (cy - size / 2).coerceIn(0f, (dm.heightPixels - size).toFloat())
        val x0 = params.x; val y0 = params.y
        s.reach = 0f; s.lookAt = null
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650
            addUpdateListener {
                val f = it.animatedValue as Float
                params.x = (x0 + (nx - x0) * f).toInt(); params.y = (y0 + (ny - y0) * f).toInt()
                runCatching { wm.updateViewLayout(s, params) }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    // يصبح شفافاً للّمس كي تضغط على الدالة تحته مباشرة
                    params.flags = params.flags or FLAG_NOT_TOUCHABLE
                    runCatching { wm.updateViewLayout(s, params) }
                    handler.postDelayed({
                        // نحسب موضع الهدف من الموضع الفعلي للنافذة على الشاشة (دقيق)
                        val loc = IntArray(2); s.getLocationOnScreen(loc)
                        s.lookAt = PointF(tx - loc[0], ty - loc[1])
                        extendedAt = System.currentTimeMillis()
                        ValueAnimator.ofFloat(0f, 1f).apply {
                            duration = 500; addUpdateListener { v -> s.reach = v.animatedValue as Float }
                        }.start()
                    }, 150)
                }
            })
        }.start()
    }

    private fun retract() {
        val s = spider ?: return; val params = lp ?: return
        if (s.reach == 0f) return
        ValueAnimator.ofFloat(s.reach, 0f).apply {
            duration = 350; addUpdateListener { s.reach = it.animatedValue as Float }
        }.start()
        params.flags = params.flags and FLAG_NOT_TOUCHABLE.inv()
        runCatching { wm.updateViewLayout(s, params) }
    }

    // ---------- البحث عن الدالة على الشاشة ----------
    private fun appRoots(): List<AccessibilityNodeInfo> =
        windows.filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
            .mapNotNull { it.root }.filter { it.packageName != packageName }

    private fun locate(name: String): RectF? {
        for (root in appRoots()) search(root, name)?.let { return it }
        return null
    }

    private fun search(n: AccessibilityNodeInfo, name: String): RectF? {
        // الأبناء أولاً: أصغر عنصر يحتوي الاسم هو الأدق
        for (k in 0 until n.childCount) {
            val c = n.getChild(k) ?: continue
            if (!c.isVisibleToUser) continue
            search(c, name)?.let { return it }
        }
        val text = n.text?.toString() ?: return null
        val dm = resources.displayMetrics
        val screen = RectF(0f, 0f, dm.widthPixels.toFloat(), dm.heightPixels.toFloat())
        var fallback: RectF? = null
        var from = 0
        while (true) {
            val i = text.indexOf(name, from)
            if (i < 0) break
            val cr = charRect(n, i, name.length)
            if (cr != null && RectF.intersects(screen, cr)) return cr      // موضع الحروف الفعلي المرئي
            if (cr == null && fallback == null) fallback = estimate(n, text, i, name.length)
            from = i + name.length
        }
        return fallback
    }

    /** موضع الحروف بدقة (Android 8+) إن كان المحرر يدعم ذلك. */
    @Suppress("DEPRECATION")
    private fun charRect(n: AccessibilityNodeInfo, start: Int, len: Int): RectF? {
        if (Build.VERSION.SDK_INT < 26) return null
        val args = Bundle().apply {
            putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_START_INDEX, start)
            putInt(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_ARG_LENGTH, len)
        }
        if (!n.refreshWithExtraData(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY, args)) return null
        val arr = n.extras.getParcelableArray(AccessibilityNodeInfo.EXTRA_DATA_TEXT_CHARACTER_LOCATION_KEY) ?: return null
        val u = RectF(); var first = true
        for (p in arr) {
            val r = p as? RectF ?: continue
            if (r.isEmpty) continue
            if (first) { u.set(r); first = false } else u.union(r)
        }
        return if (first) null else u
    }

    /** تقدير موضع السطر داخل العنصر عندما لا يدعم المحرر مواضع الحروف. */
    private fun estimate(n: AccessibilityNodeInfo, text: String, idx: Int, len: Int): RectF? {
        val b = Rect(); n.getBoundsInScreen(b)
        if (b.isEmpty) return null
        val before = text.substring(0, idx)
        val line = before.count { it == '\n' }
        val total = text.count { it == '\n' } + 1
        if (total == 1) return RectF(b)
        val lineStart = before.lastIndexOf('\n') + 1
        val lineH = b.height().toFloat() / total
        val y = b.top + lineH * (line + 0.5f)
        val x = min(b.right.toFloat() - dp(8), b.left + dp(8) + (idx - lineStart + len / 2f) * dp(7))
        return RectF(x - dp(4), y - lineH / 2, x + dp(4), y + lineH / 2)
    }

    // ---------- الاستبدال ----------
    private fun buildRegex(old: String): Regex =
        if (Regex("^[A-Za-z_$][A-Za-z0-9_$]*$").matches(old))
            Regex("(?<![A-Za-z0-9_$])" + Regex.escape(old) + "(?![A-Za-z0-9_$])")
        else Regex(Regex.escape(old))

    private fun replaceAll(old: String, new: String): Int {
        val rx = buildRegex(old); var total = 0
        fun walk(n: AccessibilityNodeInfo) {
            val t = n.text?.toString()
            if (n.isEditable && t != null) {
                val c = rx.findAll(t).count()
                if (c > 0) {
                    val out = rx.replace(t, java.util.regex.Matcher.quoteReplacement(new))
                    val args = Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, out)
                    }
                    if (n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) total += c
                }
            }
            for (k in 0 until n.childCount) n.getChild(k)?.let { walk(it) }
        }
        appRoots().forEach { walk(it) }
        return total
    }
}
