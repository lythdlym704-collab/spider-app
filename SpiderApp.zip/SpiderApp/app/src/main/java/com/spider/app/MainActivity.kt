package com.spider.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun dp(v: Int) = Ui.dp(this, v)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(24), dp(28), dp(24), dp(24))
            setBackgroundColor(Color.BLACK)
        }
        fun lpMatch(top: Int = 0) = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(top) }

        col.addView(ImageView(this).apply {
            setImageResource(R.drawable.spider_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            layoutParams = LinearLayout.LayoutParams(dp(190), dp(190))
        })
        col.addView(TextView(this).apply {
            text = "العنكبوت المبرمج"; textSize = 28f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        }, lpMatch(4))
        col.addView(TextView(this).apply {
            text = "يلمس الدالة بإصبعه ويستبدلها لك"; textSize = 14f
            setTextColor(0xFFAAAAAA.toInt()); gravity = Gravity.CENTER
        }, lpMatch(2))

        status = TextView(this).apply {
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = Ui.shape(this@MainActivity, Color.BLACK, Ui.RED, 12, 1)
        }
        col.addView(status, lpMatch(22))

        col.addView(Ui.button(this, "تفعيل العنكبوت المبرمج") {
            val s = SpiderService.instance
            if (s == null) {
                Toast.makeText(this, "فعّل خدمة «العنكبوت المبرمج» من إعدادات إمكانية الوصول ثم عد واضغط الزر", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            } else s.show()
        }, lpMatch(16))
        col.addView(Ui.button(this, "إخفاء العنكبوت") { SpiderService.instance?.hide() }, lpMatch(10))

        col.addView(TextView(this).apply {
            text = "طريقة الاستخدام\n\n" +
                "١. فعّل الخدمة ثم اضغط «تفعيل العنكبوت المبرمج».\n" +
                "٢. اضغط على العنكبوت مرة واحدة لتظهر اللوحة.\n" +
                "٣. الصق اسم الدالة واضغط «اذهب» ليلمسها بإصبعه.\n" +
                "٤. للاستبدال اكتب الدالتين واضغط «استبدال»."
            textSize = 14f; setTextColor(Color.WHITE); gravity = Gravity.START
            setLineSpacing(0f, 1.15f)
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = Ui.shape(this@MainActivity, 0xFF0A0A0A.toInt(), 0xFF8A0000.toInt(), 14, 1)
        }, lpMatch(22))

        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })
    }

    override fun onResume() {
        super.onResume()
        val on = SpiderService.instance != null
        status.text = if (on) "● الخدمة مفعّلة — يمكنك تشغيل العنكبوت"
        else "● الخدمة غير مفعّلة — فعّلها من إعدادات إمكانية الوصول"
        status.setTextColor(if (on) 0xFF4CD964.toInt() else 0xFFFF5A5A.toInt())
    }
}
