package com.spider.app

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat

class MainActivity : Activity() {
    private var picked: Bitmap? = null
    private lateinit var preview: ImageView
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(40), dp(20), dp(20)); setBackgroundColor(0xFF101010.toInt())
        }
        fun tv(t: String, sz: Float) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(Color.WHITE); gravity = Gravity.START
            setPadding(0, dp(8), 0, dp(8))
        }
        col.addView(tv("🕷️ العنكبوت المبرمج", 26f))

        col.addView(Button(this).apply {
            text = "تفعيل العنكبوت المبرمج"
            setOnClickListener {
                val s = SpiderService.instance
                if (s == null) {
                    Toast.makeText(context, "فعّل خدمة «العنكبوت المبرمج» من إعدادات إمكانية الوصول ثم عد واضغط الزر", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else s.show()
            }
        })
        col.addView(Button(this).apply {
            text = "إخفاء العنكبوت"; setOnClickListener { SpiderService.instance?.hide() }
        })

        col.addView(tv("تخصيص الاسم والأيقونة", 18f))
        val name = EditText(this).apply {
            hint = "اسم التطبيق الجديد"; setHintTextColor(0xFF888888.toInt()); setTextColor(Color.WHITE)
            setText("العنكبوت المبرمج")
        }
        col.addView(name)
        preview = ImageView(this).apply { layoutParams = LinearLayout.LayoutParams(dp(96), dp(96)) }
        col.addView(Button(this).apply {
            text = "اختيار صورة الأيقونة"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*" }, 1)
            }
        })
        col.addView(preview)
        col.addView(Button(this).apply {
            text = "إضافة اختصار بالاسم والأيقونة"
            setOnClickListener {
                val bmp = picked
                if (bmp == null) { Toast.makeText(context, "اختر صورة أولاً", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
                if (!ShortcutManagerCompat.isRequestPinShortcutSupported(context)) {
                    Toast.makeText(context, "الـ launcher لا يدعم تثبيت الاختصارات", Toast.LENGTH_LONG).show(); return@setOnClickListener
                }
                val label = name.text.toString().ifBlank { "العنكبوت" }
                val sc = ShortcutInfoCompat.Builder(context, "spider_" + System.currentTimeMillis())
                    .setShortLabel(label).setLongLabel(label)
                    .setIcon(IconCompat.createWithBitmap(bmp))
                    .setIntent(Intent(context, MainActivity::class.java).setAction(Intent.ACTION_MAIN))
                    .build()
                ShortcutManagerCompat.requestPinShortcut(context, sc, null)
            }
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        val uri = data?.data ?: return
        if (req == 1 && res == RESULT_OK) {
            contentResolver.openInputStream(uri)?.use {
                val src = BitmapFactory.decodeStream(it) ?: return
                picked = Bitmap.createScaledBitmap(src, 192, 192, true)
                preview.setImageBitmap(picked)
            }
        }
    }
}
