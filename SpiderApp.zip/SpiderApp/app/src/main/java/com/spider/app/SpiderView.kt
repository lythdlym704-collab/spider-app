package com.spider.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*

/** عنكبوت شرس بثمانية أذرع طويلة؛ ذراع واحدة تمتد نحو الهدف وعيناه تتابعانه. */
class SpiderView(c: Context) : View(c) {
    var lookAt: PointF? = null
        set(v) { field = v; invalidate() }
    var reach = 0f
        set(v) { field = v; invalidate() }
    private var t = 0f
    private val d = c.resources.displayMetrics.density

    private fun fill(c: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.toInt() }
    private fun stroke(c: Long, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c.toInt(); style = Paint.Style.STROKE; strokeWidth = w
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val legOuter = stroke(0xFF6A0000, 6.5f * d)
    private val legInner = stroke(0xFF0A0A0A, 3.5f * d)
    private val body = fill(0xFF0D0D0D)
    private val red = fill(0xFFE01010)
    private val white = fill(0xFFF2F2F2)
    private val black = fill(0xFF000000)
    private val bodyRim = stroke(0xFF8A0000, 1.5f * d)

    private val anim = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val cx = w / 2; val cy = height / 2f
        val L = w * 0.42f; val r = w * 0.09f
        val angles = floatArrayOf(-55f, -20f, 20f, 55f, 125f, 160f, 200f, 235f)
        val p = lookAt
        val legIdx = if (p != null && p.x < cx) 4 else 3
        val path = Path()
        for (i in angles.indices) {
            val a = Math.toRadians(angles[i] + sin(t + i) * 4.0).toFloat()
            val bx = cx + cos(a) * r; val by = cy + sin(a) * r
            var tx = cx + cos(a) * L; var ty = cy + sin(a) * L
            if (i == legIdx && reach > 0f && p != null) {
                var dx = p.x - cx; var dy = p.y - cy
                val dist = hypot(dx, dy); val m = w * 0.6f
                if (dist > m) { dx *= m / dist; dy *= m / dist }
                tx += (cx + dx - tx) * reach; ty += (cy + dy - ty) * reach
            }
            val kx = (bx + tx) / 2 + cos(a) * L * 0.1f
            val ky = (by + ty) / 2 - w * 0.12f
            path.reset(); path.moveTo(bx, by); path.lineTo(kx, ky); path.lineTo(tx, ty)
            cv.drawPath(path, legOuter); cv.drawPath(path, legInner)
        }
        cv.drawCircle(cx, cy + r * 0.9f, r * 1.35f, body)
        cv.drawCircle(cx, cy + r * 0.9f, r * 1.35f, bodyRim)
        cv.drawCircle(cx, cy + r * 0.9f, r * 0.3f, red)
        cv.drawCircle(cx, cy - r * 0.7f, r * 0.85f, body)
        cv.drawCircle(cx, cy - r * 0.7f, r * 0.85f, bodyRim)
        for (s in intArrayOf(-1, 1)) {
            val fx = cx + s * r * 0.28f; val fy = cy - r * 0.2f
            val fang = Path().apply {
                moveTo(fx - r * 0.12f, fy); lineTo(fx + r * 0.12f, fy); lineTo(fx, fy + r * 0.55f); close()
            }
            cv.drawPath(fang, white)
        }
        var ox = 0f; var oy = 0f
        if (p != null) {
            val dx = p.x - cx; val dy = p.y - cy; val dist = max(1f, hypot(dx, dy))
            ox = dx / dist * r * 0.1f; oy = dy / dist * r * 0.1f
        }
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * r * 0.35f; val ey = cy - r * 0.9f
            cv.drawCircle(ex, ey, r * 0.28f, red)
            cv.drawCircle(ex + ox, ey + oy, r * 0.12f, black)
        }
    }
}
