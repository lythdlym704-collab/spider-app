package com.spider.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.*

/** عنكبوت أحمر بثمانية أذرع طويلة؛ الذراع الأقرب للهدف تمتد حتى يلمس إصبعها الهدف بالضبط. */
class SpiderView(c: Context) : View(c) {
    /** موضع الهدف داخل هذا الـ View (بالبكسل). */
    var lookAt: PointF? = null
        set(v) { field = v; invalidate() }
    var reach = 0f
        set(v) { field = v; invalidate() }
    private var t = 0f
    private val d = c.resources.displayMetrics.density

    private fun fill(c: Long) = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = c.toInt() }
    private fun stroke(c: Long, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = c.toInt(); style = Paint.Style.STROKE; strokeWidth = w
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val legOuter = stroke(0xFF000000, 8f * d)
    private val legInner = stroke(0xFFE01010, 4f * d)
    private val red = fill(0xFFE01010)
    private val white = fill(0xFFFFFFFF)
    private val black = fill(0xFF000000)
    private val rim = stroke(0xFF000000, 2.5f * d)
    private val tipRing = stroke(0xFFFFFFFF, 2f * d)

    private val anim = ValueAnimator.ofFloat(0f, (2 * PI).toFloat()).apply {
        duration = 2600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val cx = w / 2; val cy = height / 2f
        val L = w * 0.42f; val r = w * 0.09f
        val angles = floatArrayOf(-55f, -20f, 20f, 55f, 125f, 160f, 200f, 235f)
        val p = lookAt

        // اختيار الذراع الأقرب لاتجاه الهدف
        var legIdx = -1
        if (p != null) {
            val ang = atan2(p.y - cy, p.x - cx)
            var best = Float.MAX_VALUE
            for (i in angles.indices) {
                val ai = Math.toRadians(angles[i].toDouble()).toFloat()
                val diff = abs(atan2(sin(ang - ai), cos(ang - ai)))
                if (diff < best) { best = diff; legIdx = i }
            }
        }

        val path = Path()
        var fingerX = 0f; var fingerY = 0f
        for (i in angles.indices) {
            val a = Math.toRadians(angles[i] + sin(t + i) * 4.0).toFloat()
            val bx = cx + cos(a) * r; val by = cy + sin(a) * r
            var tx = cx + cos(a) * L; var ty = cy + sin(a) * L
            val reaching = i == legIdx && reach > 0f && p != null
            if (reaching) {
                // الإصبع يصل إلى الهدف بالضبط عند reach = 1
                tx += (p!!.x - tx) * reach; ty += (p.y - ty) * reach
                fingerX = tx; fingerY = ty
            }
            val kx = (bx + tx) / 2 + cos(a) * L * 0.1f
            val ky = (by + ty) / 2 - w * 0.12f
            path.reset(); path.moveTo(bx, by); path.lineTo(kx, ky); path.lineTo(tx, ty)
            cv.drawPath(path, legOuter); cv.drawPath(path, legInner)
        }

        // البطن
        val abd = RectF(cx - r * 0.95f, cy + r * 0.1f, cx + r * 0.95f, cy + r * 2.5f)
        cv.drawOval(abd, red); cv.drawOval(abd, rim)
        cv.drawCircle(cx, cy + r * 1.1f, r * 0.28f, black)
        // الرأس
        cv.drawCircle(cx, cy - r * 0.7f, r * 0.85f, red)
        cv.drawCircle(cx, cy - r * 0.7f, r * 0.85f, rim)
        // الأنياب
        for (s in intArrayOf(-1, 1)) {
            val fx = cx + s * r * 0.28f; val fy = cy - r * 0.2f
            val fang = Path().apply {
                moveTo(fx - r * 0.12f, fy); lineTo(fx + r * 0.12f, fy); lineTo(fx, fy + r * 0.55f); close()
            }
            cv.drawPath(fang, white); cv.drawPath(fang, rim)
        }
        // العيون تتابع الهدف
        var ox = 0f; var oy = 0f
        if (p != null) {
            val dx = p.x - cx; val dy = p.y - cy; val dist = max(1f, hypot(dx, dy))
            ox = dx / dist * r * 0.1f; oy = dy / dist * r * 0.1f
        }
        for (s in intArrayOf(-1, 1)) {
            val ex = cx + s * r * 0.35f; val ey = cy - r * 0.9f
            cv.drawCircle(ex, ey, r * 0.28f, white)
            cv.drawCircle(ex + ox, ey + oy, r * 0.13f, black)
        }
        // علامة طرف الإصبع عند اللمس
        if (reach > 0.9f && p != null) {
            cv.drawCircle(fingerX, fingerY, 7f * d, tipRing)
            cv.drawCircle(fingerX, fingerY, 2.5f * d, white)
        }
    }
}
